

    <div class="rounded-2 mt-4 p-2 preorder-faq-btn" >
        <a class="btn btn-block text-white ps-16" href="{{route('how_to_preorder')}}"><span class="ml-3">{{translate('HOW TO PREORDER ?')}}</span></a>
    </div>

