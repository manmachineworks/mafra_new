<div class="order-summary p-4 mt-4 rounded-2 preorder-border-dashed-grey">
    <p class="fs-16 fw-700">{{ translate('Order Summary') }}</p>

    @include('preorder.common.order.order_summary')
</div>