-- Sirf data insert karne ke liye
INSERT INTO `addons` 
(`id`, `name`, `unique_identifier`, `version`, `activated`, `image`, `purchase_code`, `created_at`, `updated_at`) 
VALUES
(15, 'Google One Tap', 'google_one_tap', '1.0', 1, 'google_one_tap.png', 'your_purchase_code', '2025-11-06 12:11:48', '2025-11-06 13:44:51');