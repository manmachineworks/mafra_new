@extends('seller.layouts.app')

@section('panel_content')

<div class="aiz-titlebar mt-2 mb-4">
    <div class="row align-items-center">
        <div class="col-md-6">
            <h3 class="h3">{{ translate('Category Wise Refund Days') }}</h3>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header row gutters-5">
        <h5 class="mb-0 h6">{{ translate('All Categories') }}</h5>
        <form class="" id="sort_categories" action="" method="GET">
            <div class="box-inline pad-rgt pull-left">
                <div class="" style="min-width: 200px;">
                    <input type="text" class="form-control" id="search" name="search" @isset($sort_search)
                        value="{{ $sort_search }}" @endisset placeholder="{{ translate('Type name & Enter') }}">
                </div>
            </div>
        </form>
    </div>
    <div class="card-body">
        <table class="table aiz-table mb-0">
            <thead>
                <tr>
                    <th data-breakpoints="lg" width="5%">#</th>
                    <th data-breakpoints="lg" width="10%">{{translate('Icon')}}</th>
                    <th width="20%">{{translate('Name')}}</th>
                    <th data-breakpoints="lg" width="20%">{{ translate('Parent Category') }}</th>
                    <th data-breakpoints="lg" width="15%">{{ translate('Refund Request Time(Days)') }}</th>
                </tr>
            </thead>
            <tbody>
                @foreach($categories as $key => $category)
                @php
                $isCategoryBasedRefund = get_setting('refund_type') == 'category_based_refund';
                @endphp
                <tr>
                    <td>{{ ($key + 1) + ($categories->currentPage() - 1) * $categories->perPage() }}</td>
                    <td>
                        @if($category->icon != null)
                        <span class="avatar avatar-square avatar-xs">
                            <img src="{{ uploaded_asset($category->icon) }}" alt="{{translate('icon')}}">
                        </span>
                        @else
                        —
                        @endif
                    </td>
                    <td class="align-items-center d-flex fw-800">
                        {{ $category->getTranslation('name') }}
                        @if($category->digital == 1)
                        <img src="{{ static_asset('assets/img/digital_tag.png') }}" alt="{{translate('Digital')}}"
                            class="ml-2 h-25px" style="cursor: pointer;" title="Digital">
                        @endif
                    </td>
                    <td class="fw-600">
                        @php
                        $parent = \App\Models\Category::where('id', $category->parent_id)->first();
                        @endphp
                        @if ($parent != null)
                        {{ $parent->getTranslation('name') }}
                        @else
                        —
                        @endif
                    </td>

                    <td class="align-items-center d-flex fw-800">
                        {{ $category->refund_request_time ?? 0}}
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
        <div class="aiz-pagination">
            {{ $categories->appends(request()->input())->links() }}
        </div>
    </div>
</div>
@endsection